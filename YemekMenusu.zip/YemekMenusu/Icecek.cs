﻿class Icecek : Yiyecek
{
    public int kalori;

    public Icecek(string a, string c, double f, double kdv, int k) : base(a, c, f, kdv)
    {
        kalori = k;
    }

    public override string yazdir()
    {
        return base.yazdir() + $" {kalori} kcal";
    }
}