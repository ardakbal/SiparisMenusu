using System;
using System.Windows.Forms;

namespace YemekMenusu
{
    public partial class Form1 : Form
    {
        Yiyecek? s = null;     // Eklenecek yiyecek ge�ici olarak burada tutulur
        Menu m = new Menu();  // Men� nesnesi

        public Form1()
        {
            InitializeComponent(); // Form elemanlar�n� ba�lat�r
            btnTemizle.Click += new EventHandler(btnTemizle_Click);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count == 0) // Daha �nce eklenmemi�se
            {
                comboBox1.Items.AddRange(new string[] { "Meyve", "Salata", "Tatli", "Icecek" });
            }
        }

        // ------ �R�N EKLEME BUTONUNUN FONKS�YONU ------
        private void btnEkle_Click(object sender, EventArgs e)
        {
            // Girdi alma par�as�
            string adi = txtAdi.Text;
            string cins = txtCins.Text;

            // Say�sal de�erleri kontrol etme par�as�
            if (!double.TryParse(txtFiyat.Text, out double fiyat) ||
                !double.TryParse(txtKDV.Text, out double kdv) ||
                !int.TryParse(txtKalori.Text, out int kalori))
            {
                MessageBox.Show("L�tfen ge�erli say�sal de�erler girin!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Giri� alanlar�n� temizle
                txtAdi.Text = "";
                txtCins.Text = "";
                txtFiyat.Text = "";
                txtKDV.Text = "";
                txtKalori.Text = "";
                comboBox1.SelectedIndex = -1; // ComboBox se�imini s�f�rlamak i�in -1 indeksi kullan�l�r
                return; // ��lemi durdur
            }

            string tur = comboBox1.Text;

            // T�r�ne g�re uygun nesne olu�tur
            if (tur == "Meyve")
                s = new Meyve(adi, cins, fiyat, kdv, kalori);
            else if (tur == "Salata")
                s = new Salata(adi, cins, fiyat, kdv, kalori);
            else if (tur == "Tatli")
                s = new Tatli(adi, cins, fiyat, kdv, kalori);
            else if (tur == "Icecek")
                s = new Icecek(adi, cins, fiyat, kdv, kalori);

            // Message box k�sm� ve kontroller
            if (s != null && fiyat > 0 && kalori >= 0 && kdv > 0 && kdv <= 100)
            {
                MessageBox.Show("Men� kabul edildi!");
                m.Ekle(s);
            }
            else
            {
                MessageBox.Show("Ge�ersiz giri�!");
            }

            // Listeyi temizle ve tekrar yazd�r
            listBox1.Items.Clear();

            double toplamTutar = 0; // Toplam tutar� saklayacak de�i�ken

            foreach (var item in m.MenuYazdir())
            {
                listBox1.Items.Add(item.yazdir());
                toplamTutar += item.fiyat; // Her eklenen �r�n�n fiyat�n� topla
            }

            // Toplam tutar yazd�rma kutusu
            lblToplamTutar.Text = $"Toplam Tutar: {toplamTutar} TL";

          
            txtAdi.Text    = "";
            txtCins.Text   = "";
            txtFiyat.Text  = "";
            txtKDV.Text    = "";
            txtKalori.Text = "";
            comboBox1.SelectedIndex = -1; 
        }

        // ----- SE� VE S�L BUTONUNUN FONKS�YONU ----------
        private void btnSil_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1) // E�er listede se�ilmemi� bir ��e yoksa
            {
                int secilenIndex = listBox1.SelectedIndex; // Kullan�c�n�n se�ti�i index
                m.Sil(secilenIndex);                       // Menu class'�ndaki silme metodunu �a��r
                listBox1.Items.RemoveAt(secilenIndex);     // ListBox'tan da �r�n� kald�r

                // Silme i�lemleri sonras� toplam tutar� tekrar hesapla
                double toplamTutar = 0;
                listBox1.Items.Clear(); // Listeyi temizleyelim ki silinmi� verileri hesaplamayal�m
                foreach (var item in m.MenuYazdir()) 
                {
                    listBox1.Items.Add(item.yazdir()); // Geriye kalanlar� tekrar ekleyelim
                    toplamTutar += item.fiyat;
                }

                lblToplamTutar.Text = $"Toplam Tutar: {toplamTutar} TL"; // G�ncellenmi� toplam fiyat� yazd�r
            }
            else
            {
                MessageBox.Show("L�tfen silmek i�in bir ��e se�in!", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnTemizle_Click(object? sender, EventArgs e)
        {
            // Listbox'� temizle
            listBox1.Items.Clear();

            // Toplam tutar� s�f�rla
            lblToplamTutar.Text = "Toplam Tutar: 0 TL";

            // Men� i�eri�ini s�f�rla
            m = new Menu();
        }
    }
}