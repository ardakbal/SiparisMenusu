﻿using System.Collections.Generic;

class Menu
{
    private List<Yiyecek> liste = new List<Yiyecek>();

    public void Ekle(Yiyecek y)
    {
        liste.Add(y);
    }
    public void Sil(int index)
    {
        if (index >= 0 && index < liste.Count)
            liste.RemoveAt(index);
    }
    public List<Yiyecek> MenuYazdir()
    {
        return liste;
    }
}