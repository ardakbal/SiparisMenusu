﻿class Salata : Yiyecek
{
    public int kalori;

    public Salata(string a, string c, double f, double kdv, int k) : base(a, c, f, kdv)
    {
        kalori = k;
    }

    public override string yazdir()
    {
        return base.yazdir() + $" {kalori} kcal";
    }
}