﻿namespace YemekMenusu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1 = new ComboBox();
            txtAdi = new TextBox();
            txtCins = new TextBox();
            txtFiyat = new TextBox();
            txtKDV = new TextBox();
            txtKalori = new TextBox();
            btnEkle = new Button();
            listBox1 = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lblToplamTutar = new Label();
            btnTemizle = new Button();
            btnSil = new Button();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(167, 75);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(125, 28);
            comboBox1.TabIndex = 0;
            // 
            // txtAdi
            // 
            txtAdi.Location = new Point(167, 119);
            txtAdi.Name = "txtAdi";
            txtAdi.Size = new Size(125, 27);
            txtAdi.TabIndex = 1;
            // 
            // txtCins
            // 
            txtCins.Location = new Point(167, 152);
            txtCins.Name = "txtCins";
            txtCins.Size = new Size(125, 27);
            txtCins.TabIndex = 2;
            // 
            // txtFiyat
            // 
            txtFiyat.Location = new Point(167, 185);
            txtFiyat.Name = "txtFiyat";
            txtFiyat.Size = new Size(125, 27);
            txtFiyat.TabIndex = 3;
            // 
            // txtKDV
            // 
            txtKDV.Location = new Point(167, 218);
            txtKDV.Name = "txtKDV";
            txtKDV.Size = new Size(125, 27);
            txtKDV.TabIndex = 4;
            // 
            // txtKalori
            // 
            txtKalori.Location = new Point(167, 251);
            txtKalori.Name = "txtKalori";
            txtKalori.Size = new Size(125, 27);
            txtKalori.TabIndex = 5;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(198, 284);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 6;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(384, 51);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(313, 244);
            listBox1.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(76, 78);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 9;
            label1.Text = "Yiyecek Seç\r\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(129, 122);
            label2.Name = "label2";
            label2.Size = new Size(32, 20);
            label2.TabIndex = 10;
            label2.Text = "Adı";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(121, 155);
            label3.Name = "label3";
            label3.Size = new Size(40, 20);
            label3.TabIndex = 11;
            label3.Text = "Cinsi";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(117, 188);
            label4.Name = "label4";
            label4.Size = new Size(44, 20);
            label4.TabIndex = 12;
            label4.Text = "Fiyatı";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(83, 221);
            label5.Name = "label5";
            label5.Size = new Size(78, 20);
            label5.TabIndex = 13;
            label5.Text = "KDV Oranı";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(113, 254);
            label6.Name = "label6";
            label6.Size = new Size(48, 20);
            label6.TabIndex = 14;
            label6.Text = "Kalori";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label7.Location = new Point(384, 20);
            label7.Name = "label7";
            label7.Size = new Size(144, 28);
            label7.TabIndex = 15;
            label7.Text = "Sipariş Menüsü";
            // 
            // lblToplamTutar
            // 
            lblToplamTutar.AutoSize = true;
            lblToplamTutar.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblToplamTutar.Location = new Point(384, 298);
            lblToplamTutar.Name = "lblToplamTutar";
            lblToplamTutar.Size = new Size(131, 20);
            lblToplamTutar.TabIndex = 16;
            lblToplamTutar.Text = "Toplam Tutar: 0 TL";
            // 
            // btnTemizle
            // 
            btnTemizle.Location = new Point(531, 301);
            btnTemizle.Name = "btnTemizle";
            btnTemizle.Size = new Size(166, 29);
            btnTemizle.TabIndex = 17;
            btnTemizle.Text = "Tamamını sil";
            btnTemizle.UseVisualStyleBackColor = true;
            btnTemizle.Click += btnTemizle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(531, 336);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(166, 29);
            btnSil.TabIndex = 18;
            btnSil.Text = "Seç ve sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(726, 411);
            Controls.Add(btnSil);
            Controls.Add(btnTemizle);
            Controls.Add(lblToplamTutar);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(listBox1);
            Controls.Add(btnEkle);
            Controls.Add(txtKalori);
            Controls.Add(txtKDV);
            Controls.Add(txtFiyat);
            Controls.Add(txtCins);
            Controls.Add(txtAdi);
            Controls.Add(comboBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            Click += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private TextBox txtAdi;
        private TextBox txtCins;
        private TextBox txtFiyat;
        private TextBox txtKDV;
        private TextBox txtKalori;
        private Button btnEkle;
        private ListBox listBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label lblToplamTutar;
        private Button btnTemizle;
        private Button btnSil;
    }
}
